package PageMethods;

import Core.BasePage;
import org.openqa.selenium.By;

public class DemoQaHomepage extends BasePage {


    public void clickOnElements(){
        clickOnElement(By.xpath(""));
    }
}
